import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner (System.in);
    long sum = 0;
    int cases = keyboard.nextInt();

    for (int i = 0; i < cases; i++){
      int num2 = keyboard.nextInt();
      sum += Math.pow(num2 /10, num2 % 10);
    }

    System.out.println(sum);
  }
}