import java.util.*;
import java.io.*;

class Main {
  public static void main(String[] args) throws Exception {

    // Scanner input1 = new Scanner(System.in);
    // --To speed up--
    BufferedReader input1 = new BufferedReader(new InputStreamReader(System.in));
    // ---------INPUT N----------
    int cases = Integer.parseInt(input1.readLine());
    // int cases = input1.Int(); // num of cases
    for (int i = 0; i < cases; i++) {
      List<Vertex> vertices = new ArrayList<>();// create a list of vertices

      // -------INPUT M-----------
      int m = Integer.parseInt(input1.readLine());
      // int m = input1.nextInt(); // num of islands m

      double[] array1 = new double[m];
      double[] array2 = new double[m];

      for (int j = 0; j < m; j++) { // coordinates
        String[] line = input1.readLine().split(" ");
        double x = Double.parseDouble(line[0]);
        // double x = input1.nextDouble();
        double y = Double.parseDouble(line[1]);
        // double y = input1.nextDouble();
        array1[j] = x;
        // going thru m points. j going to m-1
        array2[j] = y;

        vertices.add(new Vertex(j));// point i am on is j(in this for loop).This is the vertex ID.
      }

      // for - go thru all points
      for (int j = 0; j < m; j++) {
        for (int k = j + 1; k < m; k++) { // for - start at the point(the previous) and go to the end)
          double x1 = array1[j]; // index is j(for the nearest loop)
          double y1 = array2[j];
          double x2 = array1[k]; // index is k (k=j+1)
          double y2 = array2[k];

          double distance = (Math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1)));

          vertices.get(j).adj.add(new Edge(vertices.get(j), vertices.get(k), distance));
          vertices.get(k).adj.add(new Edge(vertices.get(k), vertices.get(j), distance));
        }
      }

      // --------------OUTPUT-----------
      mst(vertices); // call mst
      System.out.println(mstWeight);
    }

  }

  // create the ID
  static class Vertex {
    int id; // create a vertex ID
    List<Edge> adj = new ArrayList<>();

  //Pass an num, and the num go thru id
    Vertex(int a) {
      id = a;
    }
  }
  static class Edge implements Comparable<Edge> {
    double weight;
    Vertex target;
    Vertex src; //source - where it will go from again
    
    Edge(Vertex s, Vertex t, double w) {
      weight = w;
      target = t;
      src = s;
    }

    public int compareTo(Edge e) {
      return Double.compare(weight, e.weight);
    }
  }

  // this class is to store the edges in MST
  // if only need the MST weight, then ignore this
  static class IntPair {
    int v1, v2;

    IntPair(int a, int b) {
      v1 = a;
      v2 = b;
    }
  }

  static double mstWeight;

  // took a graph and return the MST, or don't return anything if just need the
  // min cost
  public static List<IntPair> mst(List<Vertex> vertices) {
    mstWeight = 0;
    List<IntPair> result = new ArrayList<>(); // store the MST
    boolean[] visited = new boolean[vertices.size()];
    visited[0] = true;
    PriorityQueue<Edge> pq = new PriorityQueue<>();
    for (Edge e : vertices.get(0).adj)
      pq.offer(e);
    while (!pq.isEmpty()) {
      Edge u = pq.poll();
      if (!visited[u.target.id]) {
        mstWeight += u.weight;
        result.add(new IntPair(u.src.id, u.target.id)); // store the MST
        visited[u.target.id] = true;
        for (Edge e : u.target.adj) {
          if (!visited[e.target.id])
            pq.offer(e);
        }
      }
    }
    return result; // return MST
  }

}
