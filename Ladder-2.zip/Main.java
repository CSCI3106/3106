import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
        System.out.println((int)(keyboard.nextDouble() / Math.sin(Math.toRadians(keyboard.nextDouble()))));
    }


    
}