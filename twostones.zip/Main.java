import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    int input = keyboard.nextInt();
    if (input % 2 == 0) {
      System.out.println("Bob");
    } else {
      System.out.println("Alice");
    }
  }
}