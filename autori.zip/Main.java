import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    // String input1 = keyboard.nextLine();
    String[] arr1 = keyboard.nextLine().split("-");
    ;

    for (int i = 0; i < arr1.length; i++) {
      System.out.print(arr1[i].charAt(0));

    }

  }
}