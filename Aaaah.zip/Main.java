import java.util.*;

public class Main {
  
  public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        if(keyboard.nextLine().length() >= keyboard.nextLine().length())
            System.out.println("go");
        else
            System.out.println("no");
    }

}