import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    int hr = keyboard.nextInt();
    int min = keyboard.nextInt();

    int difference = min - 45;

    if (difference < 0) {
      min = 60 + difference;
      if (hr == 0)
        hr = 24;
      System.out.println(hr - 1 + " " + min);
    } else

      System.out.println(hr + " " + difference);
  }
}
