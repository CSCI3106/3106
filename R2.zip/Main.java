import java.util.*;

class Main {
  public static void main(String[] args) {

    Scanner keyboard = new Scanner(System.in);
    int R1 = keyboard.nextInt();
    int S = keyboard.nextInt();
    System.out.println(S-(R1-S));



  }
}