import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    int a = keyboard.nextInt();
    int b = keyboard.nextInt();
    int c = keyboard.nextInt();

    // a+b=c and a=b+c
    if (a + b == c) {
      System.out.println(a + "+" + b + "=" + c);
    } else if (a == b + c) {
      System.out.println(a + "=" + b + "+" + c);
    } else if (a == b - c) {
      System.out.println(a + "=" + b + "-" + c);
    } else if (a - b == c) {
      System.out.println(a + "-" + b + "=" + c);
    } else if (a * b == c) {
      System.out.println(a + "*" + b + "=" + c);
    } else if (a == b * c) {
      System.out.println(a + "=" + b + "*" + c);
    } else if (a / b == c) {
      System.out.println(a + "/" + b + "=" + c);
    } else if (a == b / c) {
      System.out.println(a + "=" + b + "/" + c);
    }

  }
}
